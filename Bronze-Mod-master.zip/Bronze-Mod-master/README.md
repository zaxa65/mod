# Bronze-Mod
Mod is all oriented around bronze (kind of not anymore) and adds 6 new materials and many more buildings. 

Current plans can be viewed on Projects page 

## This mod currently adds: (Last updated- v3.0)
#### Materials
- Tin
- Bronze
- Iron
- Steel
- Bronzium
- Intrium
- Natrium
#### Blocks
- Bronze, Steel Solar panels
- Bronze, Steel, Bronzium Generators
- Bronze, Steel, Bronzium Drills
- Bronze, Steel, Bronzium Conveyors (Sprites made by Retrothopter)
- Bronze, Steel, Bronzium Walls
- Bronze, Steel, Bronzium Forges - This is where those alloys are made
- Bronzium Mender (Currently missing Sprite)
- Bronzium ForceField Projector (Currently missing Sprite)
- Bronzium Power Node (Currently missing Sprite)
- Scrapper - Currently only way to make Iron 
- Bronzium Vault
- Bronze Router (3x3 version of router, requested by Pomepyr)
#### Turrets 
- Bronze Turret (Currently missing sprite and is currently WIP)
#### Items added by SomeRandomPerson
- Natrium
- Intrium
- Natrium Forge
- Natrium Generator


### UPDATE 3.0 RELEASED! One of the biggest updates ever! New material and many new buildings!
